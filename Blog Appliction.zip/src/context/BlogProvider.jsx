import React, { createContext, useEffect, useState } from "react";

export const BlogContext = createContext();

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:3000";

function BlogProvider({ children }) {
  const [blogData, setBlogData] = useState("");

  const getBlogData = async () => {
    const raw = await fetch(`${API_BASE_URL}/blog`);
    if (!raw.ok) {
      throw new Error(`Failed to fetch blog data: ${raw.status}`);
    }
    const data = await raw.json();
    return data;
  };

  useEffect(() => {
    getBlogData()
      .then((data) => setBlogData(data))
      .catch(() => setBlogData([]));
  }, []);

  return (
    <>
      <BlogContext.Provider value={blogData}>{children}</BlogContext.Provider>
    </>
  );
}

export default BlogProvider;
