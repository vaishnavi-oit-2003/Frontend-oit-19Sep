import React, { useEffect, useState } from 'react'
import Navbar from './components/Navbar'

const  App = () => {


  const VALID_THEMES = ['light', 'dark'];
  const stored_theme = localStorage.getItem('current_theme');
  const current_theme = VALID_THEMES.includes(stored_theme) ? stored_theme : 'light';
  const [theme, setTheme] = useState(current_theme);
  useEffect(()=>{
     localStorage.setItem('current_theme',theme);
  },[theme])
  return (
    <div className={`container ${theme}`}>
    <Navbar theme={theme} setTheme={setTheme} />

    </div>
  )
}

export default App
